﻿namespace Chiecnonkidieu
{
    partial class FormPlaygame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormPlaygame));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btr = new System.Windows.Forms.Button();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.btq = new System.Windows.Forms.Button();
            this.btp = new System.Windows.Forms.Button();
            this.bto = new System.Windows.Forms.Button();
            this.btn = new System.Windows.Forms.Button();
            this.btm = new System.Windows.Forms.Button();
            this.btz = new System.Windows.Forms.Button();
            this.btw = new System.Windows.Forms.Button();
            this.bty = new System.Windows.Forms.Button();
            this.btx = new System.Windows.Forms.Button();
            this.btv = new System.Windows.Forms.Button();
            this.btu = new System.Windows.Forms.Button();
            this.btt = new System.Windows.Forms.Button();
            this.bts = new System.Windows.Forms.Button();
            this.btj = new System.Windows.Forms.Button();
            this.btl = new System.Windows.Forms.Button();
            this.bti = new System.Windows.Forms.Button();
            this.btk = new System.Windows.Forms.Button();
            this.bth = new System.Windows.Forms.Button();
            this.btg = new System.Windows.Forms.Button();
            this.btf = new System.Windows.Forms.Button();
            this.bte = new System.Windows.Forms.Button();
            this.btd = new System.Windows.Forms.Button();
            this.btc = new System.Windows.Forms.Button();
            this.btb = new System.Windows.Forms.Button();
            this.bta = new System.Windows.Forms.Button();
            this.btchoi = new System.Windows.Forms.Button();
            this.btthoat = new System.Windows.Forms.Button();
            this.gbdapan = new System.Windows.Forms.GroupBox();
            this.lbstatus = new System.Windows.Forms.Label();
            this.txtdiem = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMang = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.lbchoi = new System.Windows.Forms.Label();
            this.lbthongbao = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.gbdapan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.btr);
            this.groupBox2.Controls.Add(this.progressBar);
            this.groupBox2.Controls.Add(this.btq);
            this.groupBox2.Controls.Add(this.btp);
            this.groupBox2.Controls.Add(this.bto);
            this.groupBox2.Controls.Add(this.btn);
            this.groupBox2.Controls.Add(this.btm);
            this.groupBox2.Controls.Add(this.btz);
            this.groupBox2.Controls.Add(this.btw);
            this.groupBox2.Controls.Add(this.bty);
            this.groupBox2.Controls.Add(this.btx);
            this.groupBox2.Controls.Add(this.btv);
            this.groupBox2.Controls.Add(this.btu);
            this.groupBox2.Controls.Add(this.btt);
            this.groupBox2.Controls.Add(this.bts);
            this.groupBox2.Controls.Add(this.btj);
            this.groupBox2.Controls.Add(this.btl);
            this.groupBox2.Controls.Add(this.bti);
            this.groupBox2.Controls.Add(this.btk);
            this.groupBox2.Controls.Add(this.bth);
            this.groupBox2.Controls.Add(this.btg);
            this.groupBox2.Controls.Add(this.btf);
            this.groupBox2.Controls.Add(this.bte);
            this.groupBox2.Controls.Add(this.btd);
            this.groupBox2.Controls.Add(this.btc);
            this.groupBox2.Controls.Add(this.btb);
            this.groupBox2.Controls.Add(this.bta);
            this.groupBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.groupBox2.Location = new System.Drawing.Point(13, 301);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(387, 141);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Câu Trả Lời";
            // 
            // btr
            // 
            this.btr.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btr.Location = new System.Drawing.Point(14, 94);
            this.btr.Name = "btr";
            this.btr.Size = new System.Drawing.Size(35, 28);
            this.btr.TabIndex = 0;
            this.btr.Text = "R";
            this.btr.UseVisualStyleBackColor = true;
            this.btr.Click += new System.EventHandler(this.button1_Click);
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(130, 160);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(100, 23);
            this.progressBar.TabIndex = 10;
            this.progressBar.Visible = false;
            // 
            // btq
            // 
            this.btq.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btq.Location = new System.Drawing.Point(342, 62);
            this.btq.Name = "btq";
            this.btq.Size = new System.Drawing.Size(35, 26);
            this.btq.TabIndex = 0;
            this.btq.Text = "Q";
            this.btq.UseVisualStyleBackColor = true;
            this.btq.Click += new System.EventHandler(this.button1_Click);
            // 
            // btp
            // 
            this.btp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btp.Location = new System.Drawing.Point(301, 62);
            this.btp.Name = "btp";
            this.btp.Size = new System.Drawing.Size(35, 26);
            this.btp.TabIndex = 0;
            this.btp.Text = "P";
            this.btp.UseVisualStyleBackColor = true;
            this.btp.Click += new System.EventHandler(this.button1_Click);
            // 
            // bto
            // 
            this.bto.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bto.Location = new System.Drawing.Point(260, 62);
            this.bto.Name = "bto";
            this.bto.Size = new System.Drawing.Size(35, 26);
            this.bto.TabIndex = 0;
            this.bto.Text = "O";
            this.bto.UseVisualStyleBackColor = true;
            this.bto.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn
            // 
            this.btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn.Location = new System.Drawing.Point(219, 62);
            this.btn.Name = "btn";
            this.btn.Size = new System.Drawing.Size(35, 26);
            this.btn.TabIndex = 0;
            this.btn.Text = "N";
            this.btn.UseVisualStyleBackColor = true;
            this.btn.Click += new System.EventHandler(this.button1_Click);
            // 
            // btm
            // 
            this.btm.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btm.Location = new System.Drawing.Point(178, 62);
            this.btm.Name = "btm";
            this.btm.Size = new System.Drawing.Size(35, 26);
            this.btm.TabIndex = 0;
            this.btm.Text = "M";
            this.btm.UseVisualStyleBackColor = true;
            this.btm.Click += new System.EventHandler(this.button1_Click);
            // 
            // btz
            // 
            this.btz.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btz.Location = new System.Drawing.Point(342, 94);
            this.btz.Name = "btz";
            this.btz.Size = new System.Drawing.Size(35, 28);
            this.btz.TabIndex = 0;
            this.btz.Text = "Z";
            this.btz.UseVisualStyleBackColor = true;
            this.btz.Click += new System.EventHandler(this.button1_Click);
            // 
            // btw
            // 
            this.btw.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btw.Location = new System.Drawing.Point(301, 94);
            this.btw.Name = "btw";
            this.btw.Size = new System.Drawing.Size(35, 28);
            this.btw.TabIndex = 0;
            this.btw.Text = "W";
            this.btw.UseVisualStyleBackColor = true;
            this.btw.Click += new System.EventHandler(this.button1_Click);
            // 
            // bty
            // 
            this.bty.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bty.Location = new System.Drawing.Point(260, 94);
            this.bty.Name = "bty";
            this.bty.Size = new System.Drawing.Size(35, 28);
            this.bty.TabIndex = 0;
            this.bty.Text = "Y";
            this.bty.UseVisualStyleBackColor = true;
            this.bty.Click += new System.EventHandler(this.button1_Click);
            // 
            // btx
            // 
            this.btx.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btx.Location = new System.Drawing.Point(219, 94);
            this.btx.Name = "btx";
            this.btx.Size = new System.Drawing.Size(35, 28);
            this.btx.TabIndex = 0;
            this.btx.Text = "X";
            this.btx.UseVisualStyleBackColor = true;
            this.btx.Click += new System.EventHandler(this.button1_Click);
            // 
            // btv
            // 
            this.btv.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btv.Location = new System.Drawing.Point(178, 94);
            this.btv.Name = "btv";
            this.btv.Size = new System.Drawing.Size(35, 28);
            this.btv.TabIndex = 0;
            this.btv.Text = "V";
            this.btv.UseVisualStyleBackColor = true;
            this.btv.Click += new System.EventHandler(this.button1_Click);
            // 
            // btu
            // 
            this.btu.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btu.Location = new System.Drawing.Point(137, 94);
            this.btu.Name = "btu";
            this.btu.Size = new System.Drawing.Size(35, 28);
            this.btu.TabIndex = 0;
            this.btu.Text = "U";
            this.btu.UseVisualStyleBackColor = true;
            this.btu.Click += new System.EventHandler(this.button1_Click);
            // 
            // btt
            // 
            this.btt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt.Location = new System.Drawing.Point(96, 94);
            this.btt.Name = "btt";
            this.btt.Size = new System.Drawing.Size(35, 28);
            this.btt.TabIndex = 0;
            this.btt.Text = "T";
            this.btt.UseVisualStyleBackColor = true;
            this.btt.Click += new System.EventHandler(this.button1_Click);
            // 
            // bts
            // 
            this.bts.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bts.Location = new System.Drawing.Point(55, 94);
            this.bts.Name = "bts";
            this.bts.Size = new System.Drawing.Size(35, 28);
            this.bts.TabIndex = 0;
            this.bts.Text = "S";
            this.bts.UseVisualStyleBackColor = true;
            this.bts.Click += new System.EventHandler(this.button1_Click);
            // 
            // btj
            // 
            this.btj.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btj.Location = new System.Drawing.Point(52, 62);
            this.btj.Name = "btj";
            this.btj.Size = new System.Drawing.Size(35, 26);
            this.btj.TabIndex = 0;
            this.btj.Text = "J";
            this.btj.UseVisualStyleBackColor = true;
            this.btj.Click += new System.EventHandler(this.button1_Click);
            // 
            // btl
            // 
            this.btl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btl.Location = new System.Drawing.Point(135, 62);
            this.btl.Name = "btl";
            this.btl.Size = new System.Drawing.Size(35, 26);
            this.btl.TabIndex = 0;
            this.btl.Text = "L";
            this.btl.UseVisualStyleBackColor = true;
            this.btl.Click += new System.EventHandler(this.button1_Click);
            // 
            // bti
            // 
            this.bti.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bti.Location = new System.Drawing.Point(11, 62);
            this.bti.Name = "bti";
            this.bti.Size = new System.Drawing.Size(35, 26);
            this.bti.TabIndex = 0;
            this.bti.Text = "I";
            this.bti.UseVisualStyleBackColor = true;
            this.bti.Click += new System.EventHandler(this.button1_Click);
            // 
            // btk
            // 
            this.btk.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btk.Location = new System.Drawing.Point(93, 62);
            this.btk.Name = "btk";
            this.btk.Size = new System.Drawing.Size(35, 26);
            this.btk.TabIndex = 0;
            this.btk.Text = "K";
            this.btk.UseVisualStyleBackColor = true;
            this.btk.Click += new System.EventHandler(this.button1_Click);
            // 
            // bth
            // 
            this.bth.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bth.Location = new System.Drawing.Point(312, 29);
            this.bth.Name = "bth";
            this.bth.Size = new System.Drawing.Size(35, 27);
            this.bth.TabIndex = 0;
            this.bth.Text = "H";
            this.bth.UseVisualStyleBackColor = true;
            this.bth.Click += new System.EventHandler(this.button1_Click);
            // 
            // btg
            // 
            this.btg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btg.Location = new System.Drawing.Point(271, 29);
            this.btg.Name = "btg";
            this.btg.Size = new System.Drawing.Size(35, 27);
            this.btg.TabIndex = 0;
            this.btg.Text = "G";
            this.btg.UseVisualStyleBackColor = true;
            this.btg.Click += new System.EventHandler(this.button1_Click);
            // 
            // btf
            // 
            this.btf.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btf.Location = new System.Drawing.Point(230, 29);
            this.btf.Name = "btf";
            this.btf.Size = new System.Drawing.Size(35, 27);
            this.btf.TabIndex = 0;
            this.btf.Text = "F";
            this.btf.UseVisualStyleBackColor = true;
            this.btf.Click += new System.EventHandler(this.button1_Click);
            // 
            // bte
            // 
            this.bte.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bte.Location = new System.Drawing.Point(189, 29);
            this.bte.Name = "bte";
            this.bte.Size = new System.Drawing.Size(35, 27);
            this.bte.TabIndex = 0;
            this.bte.Text = "E";
            this.bte.UseVisualStyleBackColor = true;
            this.bte.Click += new System.EventHandler(this.button1_Click);
            // 
            // btd
            // 
            this.btd.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btd.Location = new System.Drawing.Point(148, 29);
            this.btd.Name = "btd";
            this.btd.Size = new System.Drawing.Size(35, 27);
            this.btd.TabIndex = 0;
            this.btd.Text = "D";
            this.btd.UseVisualStyleBackColor = true;
            this.btd.Click += new System.EventHandler(this.button1_Click);
            // 
            // btc
            // 
            this.btc.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btc.Location = new System.Drawing.Point(107, 29);
            this.btc.Name = "btc";
            this.btc.Size = new System.Drawing.Size(35, 27);
            this.btc.TabIndex = 0;
            this.btc.Text = "C";
            this.btc.UseVisualStyleBackColor = true;
            this.btc.Click += new System.EventHandler(this.button1_Click);
            // 
            // btb
            // 
            this.btb.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btb.Location = new System.Drawing.Point(66, 29);
            this.btb.Name = "btb";
            this.btb.Size = new System.Drawing.Size(35, 27);
            this.btb.TabIndex = 0;
            this.btb.Text = "B";
            this.btb.UseVisualStyleBackColor = true;
            this.btb.Click += new System.EventHandler(this.button1_Click);
            // 
            // bta
            // 
            this.bta.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bta.Location = new System.Drawing.Point(25, 29);
            this.bta.Name = "bta";
            this.bta.Size = new System.Drawing.Size(35, 27);
            this.bta.TabIndex = 0;
            this.bta.Text = "A";
            this.bta.UseVisualStyleBackColor = true;
            this.bta.Click += new System.EventHandler(this.button1_Click);
            // 
            // btchoi
            // 
            this.btchoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btchoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btchoi.ForeColor = System.Drawing.Color.Red;
            this.btchoi.Image = ((System.Drawing.Image)(resources.GetObject("btchoi.Image")));
            this.btchoi.Location = new System.Drawing.Point(136, 238);
            this.btchoi.Name = "btchoi";
            this.btchoi.Size = new System.Drawing.Size(84, 28);
            this.btchoi.TabIndex = 1;
            this.btchoi.Text = "CHƠI";
            this.btchoi.UseVisualStyleBackColor = true;
            this.btchoi.Click += new System.EventHandler(this.btchoi_Click);
            // 
            // btthoat
            // 
            this.btthoat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btthoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btthoat.ForeColor = System.Drawing.Color.Red;
            this.btthoat.Image = ((System.Drawing.Image)(resources.GetObject("btthoat.Image")));
            this.btthoat.Location = new System.Drawing.Point(136, 269);
            this.btthoat.Name = "btthoat";
            this.btthoat.Size = new System.Drawing.Size(84, 28);
            this.btthoat.TabIndex = 2;
            this.btthoat.Text = "THOÁT";
            this.btthoat.UseVisualStyleBackColor = true;
            this.btthoat.Click += new System.EventHandler(this.btthoat_Click);
            // 
            // gbdapan
            // 
            this.gbdapan.BackColor = System.Drawing.Color.Transparent;
            this.gbdapan.Controls.Add(this.lbstatus);
            this.gbdapan.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbdapan.ForeColor = System.Drawing.Color.AliceBlue;
            this.gbdapan.Location = new System.Drawing.Point(12, 100);
            this.gbdapan.Name = "gbdapan";
            this.gbdapan.Size = new System.Drawing.Size(795, 121);
            this.gbdapan.TabIndex = 4;
            this.gbdapan.TabStop = false;
            this.gbdapan.Text = "Đáp Án";
            // 
            // lbstatus
            // 
            this.lbstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbstatus.Location = new System.Drawing.Point(119, 159);
            this.lbstatus.Name = "lbstatus";
            this.lbstatus.Size = new System.Drawing.Size(378, 29);
            this.lbstatus.TabIndex = 0;
            this.lbstatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtdiem
            // 
            this.txtdiem.Enabled = false;
            this.txtdiem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdiem.Location = new System.Drawing.Point(68, 242);
            this.txtdiem.Multiline = true;
            this.txtdiem.Name = "txtdiem";
            this.txtdiem.Size = new System.Drawing.Size(62, 26);
            this.txtdiem.TabIndex = 6;
            this.txtdiem.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(94, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Lime;
            this.label2.Location = new System.Drawing.Point(4, 242);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 24);
            this.label2.TabIndex = 7;
            this.label2.Text = "Điểm";
            // 
            // txtMang
            // 
            this.txtMang.Enabled = false;
            this.txtMang.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMang.Location = new System.Drawing.Point(68, 273);
            this.txtMang.Multiline = true;
            this.txtMang.Name = "txtMang";
            this.txtMang.Size = new System.Drawing.Size(62, 24);
            this.txtMang.TabIndex = 6;
            this.txtMang.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Lime;
            this.label3.Location = new System.Drawing.Point(4, 269);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 24);
            this.label3.TabIndex = 7;
            this.label3.Text = "Mạng";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Enabled = false;
            this.pictureBox1.Location = new System.Drawing.Point(459, 311);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(290, 290);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // lbchoi
            // 
            this.lbchoi.BackColor = System.Drawing.Color.Transparent;
            this.lbchoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbchoi.ForeColor = System.Drawing.Color.White;
            this.lbchoi.Location = new System.Drawing.Point(12, 17);
            this.lbchoi.Name = "lbchoi";
            this.lbchoi.Size = new System.Drawing.Size(795, 71);
            this.lbchoi.TabIndex = 11;
            this.lbchoi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbthongbao
            // 
            this.lbthongbao.BackColor = System.Drawing.Color.Transparent;
            this.lbthongbao.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbthongbao.ForeColor = System.Drawing.Color.White;
            this.lbthongbao.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbthongbao.Location = new System.Drawing.Point(364, 231);
            this.lbthongbao.Name = "lbthongbao";
            this.lbthongbao.Size = new System.Drawing.Size(349, 62);
            this.lbthongbao.TabIndex = 1;
            this.lbthongbao.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FormPlaygame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(809, 454);
            this.ControlBox = false;
            this.Controls.Add(this.lbthongbao);
            this.Controls.Add(this.lbchoi);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtMang);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtdiem);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.gbdapan);
            this.Controls.Add(this.btthoat);
            this.Controls.Add(this.btchoi);
            this.Controls.Add(this.groupBox2);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FormPlaygame";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chiếc nón kỳ diệu";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormPlaygame_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.FormPlaygame_Paint);
            this.groupBox2.ResumeLayout(false);
            this.gbdapan.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btr;
        private System.Windows.Forms.Button btq;
        private System.Windows.Forms.Button btp;
        private System.Windows.Forms.Button bto;
        private System.Windows.Forms.Button btm;
        private System.Windows.Forms.Button btk;
        private System.Windows.Forms.Button bth;
        private System.Windows.Forms.Button btg;
        private System.Windows.Forms.Button btf;
        private System.Windows.Forms.Button bte;
        private System.Windows.Forms.Button btd;
        private System.Windows.Forms.Button btc;
        private System.Windows.Forms.Button btb;
        private System.Windows.Forms.Button bta;
        private System.Windows.Forms.Button bty;
        private System.Windows.Forms.Button btx;
        private System.Windows.Forms.Button btv;
        private System.Windows.Forms.Button btu;
        private System.Windows.Forms.Button btt;
        private System.Windows.Forms.Button bts;
        private System.Windows.Forms.Button bti;
        private System.Windows.Forms.Button btchoi;
        private System.Windows.Forms.Button btthoat;
        private System.Windows.Forms.GroupBox gbdapan;
        private System.Windows.Forms.TextBox txtdiem;
        private System.Windows.Forms.Label lbstatus;
        private System.Windows.Forms.Button btn;
        private System.Windows.Forms.Button btj;
        private System.Windows.Forms.Button btl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMang;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btw;
        private System.Windows.Forms.Button btz;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.Label lbchoi;
        private System.Windows.Forms.Label lbthongbao;
    }
}

